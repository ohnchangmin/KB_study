#10(1)
absent <- c(10, 8, 14, 15, 9, 10, 15, 12, 9, 7, 8, 7)
names(absent) <- c("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC") 
absent
#10(2)
absent[5]
#10(3)
absent[c(7,9)]
#10(4)
sum(absent[1:6])
#10(5)
mean(absent[7:12])