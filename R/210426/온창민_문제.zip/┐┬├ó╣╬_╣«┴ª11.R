#11(1)
d1 <- 1:50
d2 <- 51:100
d1
d2
#11(2)
length(d2)
#11(3)
d1+d2
d2-d1
d1*d2
d2/d1
#11(4)
sum(d1)
sum(d2)
#11(5)
sum(d1,d2)
#11(6)
max(d2)
min(d2)
#11(7)
mean(d2)
mean(d1)
mean(d2)-mean(d1)
#11(8)
sort(d1, decreasing = T)
#11(9)
d3 <- c(d1[1:10],d2[1:10])
d3
